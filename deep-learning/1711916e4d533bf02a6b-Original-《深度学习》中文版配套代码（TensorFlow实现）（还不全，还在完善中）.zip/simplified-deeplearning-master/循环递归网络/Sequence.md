#持续更新中。。。
## Sequence to Sequence
It is really hard to simplify because of the attention mechanism.
We have try our best to simlify the encoder-decoder architecture, which is demonstrated in the following figures.
<p align="center">
<img src="https://raw.githubusercontent.com/SwordYork/sequencing/master/docs/figures/encoder.jpg" width="45%">
<img src="https://raw.githubusercontent.com/SwordYork/sequencing/master/docs/figures/decoder.jpg" width="45%">
</p>

Please refer to [Sequencing](https://github.com/SwordYork/sequencing) for more details.
