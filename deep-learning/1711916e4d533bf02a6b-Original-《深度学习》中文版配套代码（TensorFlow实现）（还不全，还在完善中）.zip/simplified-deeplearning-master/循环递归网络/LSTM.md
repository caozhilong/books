
## Poem Generator
A simple implement of chinese poem generator with LSTM.
<p align="center">
<img src="https://raw.githubusercontent.com/hjptriplebee/Chinese_poem_generator/master/demo2.png" width = "850" height = "350" alt="demo2" />
</p>

Please refer to [MC-PangHu](https://github.com/hjptriplebee/Chinese_poem_generator).
