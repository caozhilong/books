I failed to provide a simple RBM implementation, but you could refer to the following pages.

 - [Simple RBM](http://imonad.com/rbm/restricted-boltzmann-machine/)
 - [Theano](http://deeplearning.net/tutorial/rbm.html)
 - [deeplearning4j](http://deeplearning4j.org/restrictedboltzmannmachine.html)
 - [echen's implementation](https://github.com/echen/restricted-boltzmann-machines)
